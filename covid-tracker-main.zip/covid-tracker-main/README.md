# Coronavirus (COVID-19) Tracker Dashboard

Coronavirus (COVID-19) Tracker Dashboard with Data from API - HTML CSS JavaScript

## Video coding

https://youtu.be/EoK2nIS1Zi4

## Preview

!["Coronavirus (COVID-19) Tracker Dashboard"](https://user-images.githubusercontent.com/67447840/113251512-971b0680-92ec-11eb-96cc-b928a6521e53.png "Coronavirus (COVID-19) Tracker Dashboard")
